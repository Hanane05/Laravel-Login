
let ouedknissIds = [], typeOfVehicle = 'vehicules', countListings = 50, listings = [];

function saveAsJSon() {
    var a = document.createElement("a");
    var file = new Blob([JSON.stringify(listings)], {type: 'text/plain'});
    a.href = URL.createObjectURL(file);
    a.download = (Math.ceil(Math.random()*1000000000000000)) + '.json';
    a.click();
}


getAnnouncement = (listingID) =>{
  fetch("https://api.ouedkniss.com/graphql", {
  "headers": {
    "accept": "*/*",
    "accept-language": "fr",
    "authorization": "",
    "content-type": "application/json",
    "locale": "fr",
    "sec-ch-ua": "\"Chromium\";v=\"104\", \" Not A;Brand\";v=\"99\", \"Google Chrome\";v=\"104\"",
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": "\"Windows\"",
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "same-site",
    "x-app-version": "\"1.4.14\"",
    "x-referer": "https://www.ouedkniss.com/moyenne-berline-seat-leon-2019-beats-bordj-bou-arreridj-algerie-d32838974",
    "x-track-id": "6a08cddf-62f6-4f2d-8c78-6d64561b24db",
    "x-track-timestamp": "1661518994"
  },
  "referrer": "https://www.ouedkniss.com/",
  "referrerPolicy": "strict-origin-when-cross-origin",
  "body": "{\"operationName\":\"AnnouncementGet\",\"variables\":{\"id\":\"" + ouedknissIds[listingID] + "\"},\"query\":\"query AnnouncementGet($id: ID!) {\\n  announcement: announcementDetails(id: $id) {\\n    id\\n    reference\\n    title\\n    slug\\n    description\\n    orderExternalUrl\\n    createdAt: refreshedAt\\n    price\\n    pricePreview\\n    oldPrice\\n    priceType\\n    exchangeType\\n    priceUnit\\n    hasDelivery\\n    deliveryType\\n    hasPhone\\n    hasEmail\\n    quantity\\n    status\\n    street_name\\n    category {\\n      slug\\n      name\\n      __typename\\n    }\\n    defaultMedia(size: ORIGINAL) {\\n      mediaUrl\\n      __typename\\n    }\\n    medias(size: LARGE) {\\n      mediaUrl\\n      mimeType\\n      thumbnail\\n      __typename\\n    }\\n    categories {\\n      id\\n      name\\n      slug\\n      __typename\\n    }\\n    specs {\\n      specification {\\n        label\\n        codename\\n        type\\n        __typename\\n      }\\n      value\\n      valueText\\n      __typename\\n    }\\n    user {\\n      id\\n      username\\n      displayName\\n      avatarUrl\\n      __typename\\n    }\\n    isFromStore\\n    store {\\n      id\\n      name\\n      slug\\n      description\\n      imageUrl\\n      url\\n      followerCount\\n      announcementsCount\\n      locations {\\n        location {\\n          address\\n          region {\\n            slug\\n            name\\n            __typename\\n          }\\n          __typename\\n        }\\n        __typename\\n      }\\n      categories {\\n        name\\n        slug\\n        __typename\\n      }\\n      __typename\\n    }\\n    cities {\\n      id\\n      name\\n      region {\\n        id\\n        name\\n        slug\\n        __typename\\n      }\\n      __typename\\n    }\\n    isCommentEnabled\\n    noAdsense\\n    variants {\\n      id\\n      hash\\n      specifications {\\n        specification {\\n          codename\\n          label\\n          __typename\\n        }\\n        valueText\\n        value\\n        mediaUrl\\n        __typename\\n      }\\n      price\\n      oldPrice\\n      quantity\\n      __typename\\n    }\\n    showAnalytics\\n    __typename\\n  }\\n}\\n\"}",
  "method": "POST",
  "mode": "cors",
}).then((response)=>{
  return response.json();
}).then((data)=>{
  console.log('listing...', listingID, ouedknissIds[listingID])

    listings[listingID]['announcement'] = data.data.announcement;
    nextID = listingID + 1;
    if(ouedknissIds[nextID]){
      setTimeout(function(){
        getPhones(nextID);
      }, 30000);
    }else{
      typeOfVehicle = typeOfVehicle == 'automobiles' ? 'vehicules' : 'automobiles';
      getListings(typeOfVehicle);
      saveAsJSon();
    }

})
}

getPhones = (listingID, ouedknissID) => {
fetch("https://api.ouedkniss.com/graphql", {
  "headers": {
    "accept": "*/*",
    "accept-language": "fr",
    "authorization": "",
    "content-type": "application/json",
    "locale": "fr",
    "sec-ch-ua": "\"Chromium\";v=\"104\", \" Not A;Brand\";v=\"99\", \"Google Chrome\";v=\"104\"",
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": "\"Windows\"",
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "same-site",
    "x-app-version": "\"1.4.14\"",
    "x-referer": "https://www.ouedkniss.com/moyenne-berline-seat-leon-2019-beats-bordj-bou-arreridj-algerie-d32838974",
    "x-track-id": "6a08cddf-62f6-4f2d-8c78-6d64561b24db",
    "x-track-timestamp": "1661518994"
  },
  "referrer": "https://www.ouedkniss.com/",
  "referrerPolicy": "strict-origin-when-cross-origin",
  "body": "{\"operationName\":\"UnhidePhone\",\"variables\":{\"id\":\"" + ouedknissIds[listingID] + "\"},\"query\":\"query UnhidePhone($id: ID!) {\\n  phones: announcementPhoneGet(id: $id) {\\n    id\\n    phone\\n    __typename\\n  }\\n}\\n\"}",
  "method": "POST",
  "mode": "cors"
}).then((response)=>{
  return response.json();
}).then((data)=>{
    listings[listingID]={};
    listings[listingID]['phones'] = data.data.phones.map((phnObjct) => phnObjct.phone);
    console.log(listings[listingID]['phones'])
    getAnnouncement(listingID);
});
}



getListings = (__typeOfVehicle)=>{
fetch("https://api.ouedkniss.com/graphql", {
  "headers": {
    "accept": "*/*",
    "accept-language": "fr",
    "authorization": "",
    "content-type": "application/json",
    "locale": "fr",
    "sec-ch-ua": "\"Chromium\";v=\"104\", \" Not A;Brand\";v=\"99\", \"Google Chrome\";v=\"104\"",
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": "\"Windows\"",
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "same-site",
    "x-app-version": "\"1.4.14\"",
    "x-referer": "https://www.ouedkniss.com/automobiles/3",
    "x-track-id": "6a08cddf-62f6-4f2d-8c78-6d64561b24db",
    "x-track-timestamp": "1661517401"
  },
  "referrer": "https://www.ouedkniss.com/",
  "referrerPolicy": "strict-origin-when-cross-origin",
  "body": "{\"operationName\":\"SearchQueryWithoutFilters\",\"variables\":{\"mediaSize\":\"MEDIUM\",\"q\":null,\"filter\":{\"categorySlug\":\"" + __typeOfVehicle + "\",\"origin\":null,\"connected\":false,\"delivery\":null,\"regionIds\":[],\"cityIds\":[],\"priceRange\":[null,null],\"exchange\":false,\"hasPictures\":false,\"hasPrice\":false,\"priceUnit\":null,\"fields\":[],\"page\":1,\"count\":" + countListings + "}},\"query\":\"query SearchQueryWithoutFilters($q: String, $filter: SearchFilterInput, $mediaSize: MediaSize = MEDIUM) {\\n  search(q: $q, filter: $filter) {\\n    announcements {\\n      data {\\n        ...AnnouncementContent\\n        smallDescription {\\n          valueText\\n          __typename\\n        }\\n        noAdsense\\n        __typename\\n      }\\n      paginatorInfo {\\n        lastPage\\n        hasMorePages\\n        __typename\\n      }\\n      __typename\\n    }\\n    active {\\n      category {\\n        id\\n        name\\n        delivery\\n        slug\\n        __typename\\n      }\\n      count\\n      __typename\\n    }\\n    suggested {\\n      category {\\n        id\\n        name\\n        slug\\n        __typename\\n      }\\n      count\\n      __typename\\n    }\\n    __typename\\n  }\\n}\\n\\nfragment AnnouncementContent on Announcement {\\n  id\\n  title\\n  slug\\n  createdAt: refreshedAt\\n  isFromStore\\n  isCommentEnabled\\n  userReaction {\\n    isBookmarked\\n    isLiked\\n    __typename\\n  }\\n  hasDelivery\\n  deliveryType\\n  likeCount\\n  description\\n  status\\n  cities {\\n    id\\n    name\\n    slug\\n    region {\\n      id\\n      name\\n      slug\\n      __typename\\n    }\\n    __typename\\n  }\\n  store {\\n    id\\n    name\\n    slug\\n    imageUrl\\n    __typename\\n  }\\n  defaultMedia(size: $mediaSize) {\\n    mediaUrl\\n    __typename\\n  }\\n  price\\n  pricePreview\\n  priceUnit\\n  oldPrice\\n  priceType\\n  exchangeType\\n  __typename\\n}\\n\"}",
  "method": "POST",
  "mode": "cors",
}).then((response)=>{
  return response.json();
}).then((data)=>{

    ouedknissIds = data.data.search.announcements.data.map((ths)=>ths.id);
    getPhones(0);

});
}

getListings(typeOfVehicle);
